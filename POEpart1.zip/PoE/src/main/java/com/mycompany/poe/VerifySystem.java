/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe;

/**
 *
 * @author RC_Student_lab
 */
class Login {
    public boolean checkUserName(String username){ 
        
        if(username.contains("_") && username.length()>= 5 ){
            return true; 
        }else { 
            return false; 
        }
    }   
    // a boolean that checks password
    public boolean checkpassword(String password){
        if(password.matches(".*[!@#$%^&*()_+={}:;',./<>?].*") && password.length()>=8 && password.matches(".*[A-Z].*") && password.matches(".*[a-z].*") && password.matches(".*[0-9].*")){
         return true;   
        }else{
            return false;
        }
            
    }
    //a boolean that checks number 
    public boolean checknumber (String number){
         if (number.startsWith("+27")) {
            String localPart = number.substring(3); // Remove +27

            // Check if the rest is 9 digits and all characters are digits
            if (localPart.length() == 9 && isAllDigits(localPart)) {
                String localNumber = "0" + localPart; // Convert to local format
                System.out.println("Local number: " + localNumber); // Optional: show converted number
                return false;
            }
        }

        return true;
    }

    // Helper method to check if string is only digits
    public boolean isAllDigits(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    }


 public class VerifySystem {

    private String storedUsername;
    private String storedPassword;
    private String storedNumber;
    private boolean loginSuccess;

    // Register the user and return a message
    public String registerUser(String username, String password, String number) {
        if (!username.matches("^[a-zA-Z0-9_]{5,}$")) {
            return "Username is incorrectly formatted.";
        }

        if (!isPasswordComplex(password)) {
            return "Password does not meet the complexity requirements.";
        }
        if(!number.contains("[0-9]")){
        return "Number incorrectly formated.";
    }

        storedUsername = username;
        storedPassword = password;
        storedNumber = number;
        return "User has been registered successfully.";
    }

    // Check login credentials
    public boolean loginUser(String username, String password) {
        loginSuccess = username.equals(storedUsername) && password.equals(storedPassword);
        return loginSuccess;
    }

    // Return login status message
    public String returnLoginStatus() {
        return loginSuccess ? "A successful login" : "A failed login";
    }

    // Helper method for password complexity
    private boolean isPasswordComplex(String password) {
        // Example complexity: at least 8 chars, includes digit, upper, and lower case
        return password.length() >= 8 &&
               password.matches(".[A-Z].") &&
               password.matches(".[a-z].") &&
               password.matches(".\\d.");
    }   
 }
//end

