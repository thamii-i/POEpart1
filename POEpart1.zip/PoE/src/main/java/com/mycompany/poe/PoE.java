/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;
public class PoE {

    public static void main(String[] args) {
          //creater an instance to create a class 
        
        Login objLogin = new Login(); 
        
        //creating a scanner class
        Scanner input = new Scanner(System.in); 
        String username;
        String password;
        String number;
        //prompting the user
       do {
            System.out.println("Please enter your username");
        
            username = input.nextLine();
        
        //Using if statements to check the username 
        if(objLogin.checkUserName (username) == false){
            System.out.println("The username is incorrectly formatted, re-enter");
            username = input.nextLine();
            if(objLogin.checkUserName (username) == false){
            System.out.println("The username is incorrectly formatted, re-enter");
            username = input.nextLine();
            if(objLogin.checkUserName (username) == false){
            System.out.println("The username is incorrectly formatted, re-enter");
            username = input.nextLine();
            
             
       
        }
           
       }while(objLogin.checkUserName (username) == false);
        }while(objLogin.checkUserName (username) == false);
         }while(objLogin.checkUserName (username) == false);
       
        
      
                 
   //prompting the user 
    do {
        System.out.println("Please enter your password");
        //user enters their password
        password = input.nextLine();
    //using if statments to check password
    if(objLogin.checkpassword (password) == false){
        System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a captial letter, a number, and a speciaL CHARACTER");
        password = input.nextLine();
         if(objLogin.checkpassword (password) == false){
        System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a captial letter, a number, and a speciaL CHARACTER");
        password = input.nextLine();
         if(objLogin.checkpassword (password) == false){
        System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a captial letter, a number, and a speciaL CHARACTER");
        password = input.nextLine();
         if(objLogin.checkpassword (password) == false){
        System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a captial letter, a number, and a speciaL CHARACTER");
        password = input.nextLine();
    } 
    } while(objLogin.checkpassword(password) == false);
    } while(objLogin.checkpassword(password) == false);
    } while(objLogin.checkpassword(password) == false);
    } while(objLogin.checkpassword(password) == false);
    
     
   //prompting the user 
    do {
    System.out.println("Please enter your cellphone");
    //user enters their password
     number = input.nextLine();
    
    //using if statments to check password
    if(objLogin.checknumber (number) == false){
        System.out.println("cellphone is not correctly formatted;");
        number = input.nextLine();
        if(objLogin.checknumber (number) == false){
        System.out.println("cellphone is not correctly formatted;");
        number = input.nextLine();
        if(objLogin.checknumber (number) == false){
        System.out.println("cellphone is not correctly formatted;");
        number = input.nextLine();
        if(objLogin.checknumber (number) == false){
        System.out.println("cellphone is not correctly formatted;");
        number = input.nextLine();
    }
    }while(objLogin.checknumber(number)== false);
        }while(objLogin.checknumber(number)== false);
    }while(objLogin.checknumber(number)== false);
    }while(objLogin.checknumber(number)== false);
    }
}