/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poeredesign1;


//import java.util.Scanner;
import java.util.Random;
import javax.swing.JOptionPane;
import java.util.ArrayList;

/**
 *
 * @author RC_Student_lab
 */
public class PoeRedesign1 {
  static String savedUsername = "";
    static String savedPassword = "";
    static String savedPhone = "";
    static boolean loggedIn = false;
      private static int messageCount = 0;
    private static final int MAX_MESSAGE_LENGTH = 250;

    private final String sender;
    private final String recipient;
    private final String messageText;
    private final String messageID;
    private final String messageHash;

    // Constructor
    public PoeRedesign1(String sender, String recipient, String messageText) {
        this.sender = sender;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
        messageCount++;
    }

    // Validate message ID (should be <= 10 characters)
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Validate recipient cell number (starts with '+' and max 10 digits after +)
    public boolean checkRecipientCell() {
        return recipient.startsWith("+") && recipient.length() <= 12;
    }

    // Create a message hash
    public String createMessageHash() {
        return sender.length() + ":" + messageText.substring(0, Math.min(8, messageText.length())).toUpperCase();
    }

    // Return how many messages have been sent
    public static int returnTotalMessages() {
        return messageCount;
    }

    // Generate a random message ID
    private String generateMessageID() {
        Random rand = new Random();
        return "MSG" + rand.nextInt(100000);
    }

    // Handle user decision: send, store, disregard
    public String SentMessage() {
        String[] options = {"Send", "Store", "Disregard"};
        int choice = JOptionPane.showOptionDialog(null,
                "What would you like to do with the message?",
                "Choose Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]);

        switch (choice) {
            case 0:
                return "Message successfully sent.";
            case 1:
                return "Message successfully stored.";
            case 2:
                return "Press 0 to delete message.";
            default:
                return "No valid option selected.";
        }
    }

    // Show all message information
    public void printMessages() {
        JOptionPane.showMessageDialog(null,
                "Sender: " + sender + "\n" +
                        "Recipient: " + recipient + "\n" +
                        "Message: " + messageText + "\n" +
                        "Message ID: " + messageID + "\n" +
                        "Message Hash: " + messageHash);
    }

    // Store the message in JSON-like format (simulated)
    public String storeMessage() {
        return "{ \"sender\": \"" + sender + "\", \"recipient\": \"" + recipient +
                "\", \"message\": \"" + messageText + "\", \"id\": \"" + messageID +
                "\", \"hash\": \"" + messageHash + "\" }";
    }

    // Check if the message text is valid
    public static String checkMessageLength(String message, String recipient) {
        if (message.length() > MAX_MESSAGE_LENGTH) {
            int excess = message.length() - MAX_MESSAGE_LENGTH;
            return "Message exceeds 250 characters by " + excess +
                    " characters, please reduce size.";
        }
        return "Message ready to send.";
    }

    // Entry point to simulate a chat box and multi-user login
    public static void main(String[] args) {
               while (true) {
            String[] options = {"Register", "Login", "Exit"};
            int choice = JOptionPane.showOptionDialog(null, "Welcome to QuickChat", "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            if (choice == 0) {
                registerUser();
            } else if (choice == 1) {
                if (loginUser()) {
                    chatBox();  // Go to chat menu if login is successful
                } else {
                    JOptionPane.showMessageDialog(null, "Login failed. Try again.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Goodbye!");
                break;
            }
        }
    }

    // ========== USER REGISTRATION ==========

    public static void registerUser() {
        String username = JOptionPane.showInputDialog("Enter a username (must contain '_'):");
        String password = JOptionPane.showInputDialog("Enter a password (min 8 chars, 1 capital, 1 number, 1 special char):");
        String phone = JOptionPane.showInputDialog("Enter your phone number (must start with '+' and be ≤ 13 characters):");

        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);
        boolean validPhone = checkCellPhoneNumber(phone);

        if (!validUsername) {
            JOptionPane.showMessageDialog(null, "Username is incorrectly formatted.");
        }
        if (!validPassword) {
            JOptionPane.showMessageDialog(null, "Password does not meet complexity requirements.");
        }
        if (!validPhone) {
            JOptionPane.showMessageDialog(null, "Phone number is incorrectly formatted.");
        }

        if (validUsername && validPassword && validPhone) {
            savedUsername = username;
            savedPassword = password;
            savedPhone = phone;
            JOptionPane.showMessageDialog(null, "User registered successfully!");
        }
    } 
    //Checks Username
    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    //Checks Password Complexity
    public static boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&      // Capital letter
               password.matches(".*[0-9].*") &&      // Number
               password.matches(".*[a-z].*") &&      // small
               password.matches(".*[!@#$%^&()].*"); // Special character
    }

    // Checks Cell Phone Number
    public static boolean checkCellPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("^\\+\\d{10,15}$"); // e.g. ‪+12345678901‬
    }

    // Register User
    public static String registerUser(String username, String password) {
        if (!checkUserName(username)) {
            return "The username is incorrectly formatted.";
        }
        if (!checkPasswordComplexity(password)) {
            return "The password does not meet the complexity requirements.";
        }
        return "The two above conditions have been met, and the user has been registered successfully.";
    }

     // ========== USER LOGIN ==========

    public static boolean loginUser() {
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");

        if (username.equals(savedUsername) && password.equals(savedPassword)) {
            loggedIn = true;
            JOptionPane.showMessageDialog(null, "Login successful. Welcome, " + username + "!");
            return true;
        }
        return false;
    }

    // ========== CHAT BOX ==========

    public static void chatBox() {
        while (loggedIn) {
            String[] chatOptions = {"Send Messages", "Show Recently Sent (Coming Soon)", "Logout"};
            int option = JOptionPane.showOptionDialog(null, "Choose an option:", "QuickChat",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, chatOptions, chatOptions[0]);

            if (option == 0) {
                sendMessages();
            } else if (option == 1) {
                JOptionPane.showMessageDialog(null, "Coming Soon.");
            } else if (option == 2) {
                loggedIn = false;
                JOptionPane.showMessageDialog(null, "You have been logged out.");
            }
        }
    }

    // ========== SEND MESSAGE FEATURE ==========

    public static void sendMessages() {
         boolean running = true;

        while (running) {
            String user = JOptionPane.showInputDialog("Enter username to log in:");
            if (user == null || user.isEmpty()) {
                continue;
            }

            JOptionPane.showMessageDialog(null, "Welcome to QuickChat, " + user + "!");

            int msgLimit = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to send?"));
            int sentMessages = 0;

            while (true) {
                String[] menuOptions = {"Send Messages", "Coming Soon", "Quit"};
                int option = JOptionPane.showOptionDialog(null,
                        "Choose an option:", "QuickChat Menu",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                        null, menuOptions, menuOptions[0]);

                if (option == 0) { // Send Messages
                    if (sentMessages >= msgLimit) {
                        JOptionPane.showMessageDialog(null, "Message limit reached.");
                        continue;
                    }

                    String recipient = JOptionPane.showInputDialog("Enter recipient number (start with +):");
                    String message = JOptionPane.showInputDialog("Enter your message:");

                    String lengthStatus = checkMessageLength(message, recipient);
                    if (!lengthStatus.equals("Message ready to send.")) {
                        JOptionPane.showMessageDialog(null, lengthStatus);
                        continue;
                    }

                    PoeRedesign1 m = new PoeRedesign1(user, recipient, message);
                    if (!m.checkRecipientCell()) {
                        JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or does not contain an international code. Please correct it.");
                        continue;
                    }

                    JOptionPane.showMessageDialog(null, m.SentMessage());
                    m.printMessages();
                    sentMessages++;

                } else if (option == 1) { // Coming Soon
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                } else { // Quit
                    int logout = JOptionPane.showConfirmDialog(null, "Do you want to log out?", "Logout", JOptionPane.YES_NO_OPTION);
                    if (logout == JOptionPane.YES_OPTION) {
                        break; // Log out current user
                    }
                }
            }
            //allows user to have an option to quit
            int exitApp = JOptionPane.showConfirmDialog(null, "Do you want to exit QuickChat?", "Exit", JOptionPane.YES_NO_OPTION);
            if (exitApp == JOptionPane.YES_OPTION) {
                running = false;
            }
        }

        JOptionPane.showMessageDialog(null, "Thank you for using QuickChat!");
    }
    //end of part 2
    //part3 
public class MessageHandler {
    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> messageHashes = new ArrayList<>();
    static ArrayList<String> recipients = new ArrayList<>();
    static ArrayList<String> messageIDs = new ArrayList<>();

    public static void sendMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number:");
        String message = JOptionPane.showInputDialog("Enter your message:");

        String[] options = {"Send", "Store", "Disregard"};
        int choice = JOptionPane.showOptionDialog(null, "Choose what to do with the message:",
                "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);

        String messageID = generateMessageID();
        String messageHash = generateMessageHash(message);

        messageIDs.add(messageID);
        messageHashes.add(messageHash);
        recipients.add(recipient);

        switch (choice) {
            case 0 -> {
                sentMessages.add(message);
                JOptionPane.showMessageDialog(null, "Message sent.");
            }
            case 1 -> {
                storedMessages.add(message);
                JOptionPane.showMessageDialog(null, "Message stored.");
            }
            case 2 -> {
                disregardedMessages.add(message);
                JOptionPane.showMessageDialog(null, "Message disregarded.");
            }
        }
    }

    public static void displayReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to report.");
            return;
        }

        StringBuilder report = new StringBuilder("---- Sent Messages Report ----\n");

        for (int i = 0; i < sentMessages.size(); i++) {
            report.append("Message ID: ").append(messageIDs.get(i)).append("\n");
            report.append("Recipient: ").append(recipients.get(i)).append("\n");
            report.append("Message: ").append(sentMessages.get(i)).append("\n");
            report.append("Hash: ").append(messageHashes.get(i)).append("\n\n");
        }

        JOptionPane.showMessageDialog(null, report.toString());
    }

    public static String generateMessageID() {
        return "MSG" + (messageIDs.size() + 1);
    }

    public static String generateMessageHash(String message) {
        return Integer.toHexString(message.hashCode());
    }
    /*
    Referencing.
    1.	Oracle, n.d. The Java™ Tutorials. 
    [online] Oracle. Available at: https://docs.oracle.com/javase/tutorial/ [Accessed 18 Jun. 2025].
    2.	Oracle, n.d. Class JOptionPane (Java Platform SE 8). 
    [online] Available at: https://docs.oracle.com/javase/8/docs/api/javax/swing/JOptionPane.html [Accessed 18 Jun. 2025].
    3.	Stack Overflow, n.d. Regex for password validation in Java. 
    [online] Available at: https://stackoverflow.com/questions/3802192/regexp-java-for-password-validation [Accessed 18 Jun. 2025].
    4.	Oracle, n.d. Integer.hashCode() Method Documentation. 
    [online] Available at: https://docs.oracle.com/javase/8/docs/api/java/lang/Integer.html#hashCode-- [Accessed 18 Jun. 2025].
    5.	Oracle, n.d. Class Random (Java Platform SE 8).
    [online] Available at: https://docs.oracle.com/javase/8/docs/api/java/util/Random.html [Accessed 18 Jun. 2025].
    */
}
}

