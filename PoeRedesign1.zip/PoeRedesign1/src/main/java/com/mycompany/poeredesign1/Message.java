/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poeredesign1;

import java.util.ArrayList;
import java.util.List;

import java.util.*;
import java.io.*;


/**
 *
 * @author RC_Student_lab
 */
public final class Message {
    private static int totalMessages = 0;
    private static final int messageCounter = 0;

    static String getTotalMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private final String messageId;
    private final String recipient;
    private final String message;
    private final String messageHash;
    private static final List<Message> sentMessages = new ArrayList<>();

    // Constructor
    public Message(String recipient, String message) {
        this.recipient = recipient;
        this.message = message;
        this.messageId = generateMessageID();
        this.messageHash = createMessageHash();
        totalMessages++;
    }

    // Generate a 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }

    // Validate that message ID is 10 digits
    public boolean checkMessageID() {
        return messageId.length() == 10;
    }

    // Check recipient number format: starts with + and has 10 digits after it
    public boolean checkRecipientCell() {
        return recipient.startsWith("+") && recipient.length() == 12;
    }

    // Validate that message is not over 250 characters
    public boolean isMessageValid() {
        return message.length() <= 250;
    }

    // Create message hash: first 2 of ID + : + total chars + : + first & last words
    public String createMessageHash() {
        String[] words = message.split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : "";
        return messageId.substring(0, 2) + ":" + message.length() + ":" + (first + last).toUpperCase();
    }

    // Get total messages
    public static int returnTotalMessages() {
        return totalMessages;
    }

    // Print all messages
    public static void printMessages() {
        for (Message msg : sentMessages) {
            System.out.println("To: " + msg.recipient + "\nMessage: " + msg.message + "\nHash: " + msg.messageHash);
        }
    }

    // JSON storage
    public void storeMessage() {
        JSONArray messageArray = new JSONArray();
        JSONObject obj = new JSONObject();
        obj.put("messageId", this.messageId);
        obj.put("recipient", this.recipient);
        obj.put("message", this.message);
        obj.put("messageHash", this.messageHash);

        messageArray.add(obj);

        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(messageArray.toJSONString() + "\n");
        } catch (IOException e) {
            System.out.println("Failed to store JSON message.");
        }
    }

    // Send, Disregard, Store
    public static void sendMessage(String sc) {
        while (true) {
            System.out.println("Choose an option:\n1. Send Message\n2. Disregard Message\n3. Store Message to send later");
            String choice = null;
            switch (choice) {
                case "1" -> {
                    Message msg = null;
                    sentMessages.add(msg);
                    System.out.println("Message successfully sent.");
                    return;
                }

                case "2" -> {
                    System.out.println("Press 0 to delete message.");
                    return;
                }
                case "3" -> {
                    msg.storeMessage();
                    System.out.println("Message successfully stored.");
                    return;
                }
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
    }

    String getMessageHash() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}


