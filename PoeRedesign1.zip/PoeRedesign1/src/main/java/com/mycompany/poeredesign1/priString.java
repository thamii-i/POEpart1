/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poeredesign1;

/**
 *
 * @author RC_Student_lab
 */
class priString {
     private String messageID;
    private String recipientCell;
    private String messageText;
    private String messageHash;
    private static final int totalMessagesSent = 0;
    private static final StringBuilder allMessages = new StringBuilder();
     
    
}
