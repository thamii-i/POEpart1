/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poeredesign1;

/**
 *
 * @author RC_Student_lab
 */
public class Username_Password_cellphone {
    
    public static boolean checkUserName(String username) {
    return username.contains("_") && username.length() <= 5;
    
}
      public static boolean checkPasswordComplexity(String password) {
    return password.length() >= 8 &&
           password.matches(".*[A-Z].*") &&      // Capital letter
           password.matches(".*[0-9].*") &&      // number
           password.matches(".*[a-z].*") &&      // small letter
           password.matches(".*[!@#$%^&()].*"); // Contains special character
}
      public static boolean checkCellPhoneNumber(String phoneNumber) {
    return phoneNumber.matches("^\\+\\d{10,15}$");
      }
    
    }
    

